import { createTheme, alpha } from '@mui/material/styles';

// Design tokens shared by the theme and by non-MUI code (e.g. the 3D scene).
export const tokens = {
  bg: '#0b0c0f',
  surface: '#12141a',
  border: 'rgba(255, 255, 255, 0.08)',
  borderStrong: 'rgba(255, 255, 255, 0.16)',
  text: '#e8eaed',
  textMuted: '#9aa3b2',
  accent: '#7cc4ff',
  accentSoft: '#a9d8ff',
};

const fontBody = '"Inter", system-ui, -apple-system, "Segoe UI", sans-serif';
const fontDisplay = '"Space Grotesk", "Inter", system-ui, sans-serif';
export const fontMono = '"JetBrains Mono", ui-monospace, SFMono-Regular, Menlo, monospace';

const baseTheme = createTheme({
  breakpoints: {
    values: { xs: 0, sm: 600, md: 900, lg: 1200, xl: 1536 },
  },
});

const theme = createTheme(baseTheme, {
  palette: {
    mode: 'dark',
    primary: { main: tokens.accent, contrastText: '#06101a' },
    background: { default: tokens.bg, paper: tokens.surface },
    text: { primary: tokens.text, secondary: tokens.textMuted },
    divider: tokens.border,
  },
  shape: { borderRadius: 14 },
  typography: {
    fontFamily: fontBody,
    h1: {
      fontFamily: fontDisplay,
      fontWeight: 600,
      letterSpacing: '-0.03em',
      lineHeight: 1.04,
      fontSize: 'clamp(2.6rem, 9vw, 5rem)',
    },
    h2: {
      fontFamily: fontDisplay,
      fontWeight: 600,
      letterSpacing: '-0.02em',
      lineHeight: 1.1,
      fontSize: 'clamp(1.9rem, 5.5vw, 3rem)',
    },
    h3: {
      fontFamily: fontDisplay,
      fontWeight: 600,
      letterSpacing: '-0.01em',
      fontSize: 'clamp(1.15rem, 3vw, 1.4rem)',
    },
    h4: { fontFamily: fontDisplay, fontWeight: 600, fontSize: '1.1rem' },
    subtitle1: { fontSize: 'clamp(1.05rem, 3vw, 1.4rem)', fontWeight: 500 },
    body1: { fontSize: '1rem', lineHeight: 1.7 },
    body2: { fontSize: '0.92rem', lineHeight: 1.65 },
    overline: {
      fontFamily: fontMono,
      fontSize: '0.75rem',
      letterSpacing: '0.18em',
      fontWeight: 500,
    },
    button: { textTransform: 'none', fontWeight: 500, letterSpacing: '0.01em' },
  },
  // Soft, restrained shadows (index 0 must stay 'none').
  shadows: [
    'none',
    '0 1px 2px rgba(0,0,0,0.4)',
    '0 2px 6px rgba(0,0,0,0.4)',
    '0 4px 12px rgba(0,0,0,0.4)',
    '0 6px 16px rgba(0,0,0,0.42)',
    '0 8px 20px rgba(0,0,0,0.42)',
    '0 10px 24px rgba(0,0,0,0.44)',
    '0 12px 28px rgba(0,0,0,0.44)',
    '0 14px 32px rgba(0,0,0,0.46)',
    '0 16px 36px rgba(0,0,0,0.46)',
    '0 18px 40px rgba(0,0,0,0.48)',
    '0 20px 44px rgba(0,0,0,0.48)',
    '0 22px 48px rgba(0,0,0,0.5)',
    '0 24px 52px rgba(0,0,0,0.5)',
    '0 26px 56px rgba(0,0,0,0.52)',
    '0 28px 60px rgba(0,0,0,0.52)',
    '0 30px 64px rgba(0,0,0,0.54)',
    '0 32px 68px rgba(0,0,0,0.54)',
    '0 34px 72px rgba(0,0,0,0.56)',
    '0 36px 76px rgba(0,0,0,0.56)',
    '0 38px 80px rgba(0,0,0,0.58)',
    '0 40px 84px rgba(0,0,0,0.58)',
    '0 42px 88px rgba(0,0,0,0.6)',
    '0 44px 92px rgba(0,0,0,0.6)',
    '0 46px 96px rgba(0,0,0,0.62)',
  ],
  components: {
    MuiCssBaseline: {
      styleOverrides: {
        body: { backgroundColor: tokens.bg },
        '::selection': { backgroundColor: alpha(tokens.accent, 0.3) },
      },
    },
    MuiButton: {
      defaultProps: { disableElevation: true },
      styleOverrides: {
        root: {
          borderRadius: 999,
          padding: '10px 22px',
          transition: 'transform 0.4s ease, background-color 0.3s ease, border-color 0.3s ease',
          '&:hover': { transform: 'translateY(-2px)' },
          '&.Mui-focusVisible': { outline: `2px solid ${tokens.accent}`, outlineOffset: 3 },
        },
        containedPrimary: {
          '&:hover': { backgroundColor: tokens.accentSoft },
        },
        outlined: {
          borderColor: tokens.borderStrong,
          color: tokens.text,
          '&:hover': { borderColor: tokens.accent, backgroundColor: alpha(tokens.accent, 0.06) },
        },
        sizeSmall: { padding: '6px 14px', fontSize: '0.85rem' },
      },
    },
    MuiCard: {
      styleOverrides: {
        root: {
          backgroundImage: 'none',
          backgroundColor: alpha(tokens.surface, 0.7),
          border: `1px solid ${tokens.border}`,
          backdropFilter: 'blur(10px)',
          WebkitBackdropFilter: 'blur(10px)',
          boxShadow: 'none',
          transition: 'border-color 0.4s ease, box-shadow 0.4s ease, transform 0.4s ease',
          '&:hover': {
            borderColor: tokens.borderStrong,
            boxShadow: '0 18px 40px rgba(0,0,0,0.45)',
          },
        },
      },
    },
    MuiChip: {
      styleOverrides: {
        root: {
          borderRadius: 8,
          fontFamily: fontMono,
          fontSize: '0.78rem',
          border: `1px solid ${tokens.border}`,
          backgroundColor: alpha('#ffffff', 0.03),
          transition: 'border-color 0.3s ease, background-color 0.3s ease, transform 0.3s ease',
        },
      },
    },
    MuiTextField: {
      defaultProps: { variant: 'outlined', fullWidth: true },
    },
    MuiOutlinedInput: {
      styleOverrides: {
        root: {
          borderRadius: 12,
          backgroundColor: alpha('#ffffff', 0.02),
          '& fieldset': { borderColor: tokens.border },
          '&:hover fieldset': { borderColor: tokens.borderStrong },
          '&.Mui-focused fieldset': { borderColor: tokens.accent, borderWidth: 1 },
        },
      },
    },
    MuiLink: {
      styleOverrides: {
        root: {
          '&.Mui-focusVisible, &:focus-visible': {
            outline: `2px solid ${tokens.accent}`,
            outlineOffset: 3,
            borderRadius: 4,
          },
        },
      },
    },
  },
});

export default theme;
