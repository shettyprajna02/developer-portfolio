import { Component } from 'react';

// Used around the WebGL canvas: if WebGL is unavailable the page still works without the 3D scene.
export default class ErrorBoundary extends Component {
  state = { hasError: false };

  static getDerivedStateFromError() {
    return { hasError: true };
  }

  render() {
    if (this.state.hasError) return this.props.fallback ?? null;
    return this.props.children;
  }
}
