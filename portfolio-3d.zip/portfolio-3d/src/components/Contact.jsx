import { useState } from 'react';
import Alert from '@mui/material/Alert';
import Box from '@mui/material/Box';
import Button from '@mui/material/Button';
import Link from '@mui/material/Link';
import Snackbar from '@mui/material/Snackbar';
import Stack from '@mui/material/Stack';
import TextField from '@mui/material/TextField';
import Typography from '@mui/material/Typography';
import EmailOutlinedIcon from '@mui/icons-material/EmailOutlined';
import GitHubIcon from '@mui/icons-material/GitHub';
import LinkedInIcon from '@mui/icons-material/LinkedIn';
import SendIcon from '@mui/icons-material/Send';
import Section from './Section';
import Reveal from './Reveal';
import { profile, socialLinks } from '../data/portfolio';
import { tokens } from '../theme/theme';

const contactLinks = [
  { label: 'Email', value: profile.email, href: socialLinks.email, Icon: EmailOutlinedIcon, external: false },
  { label: 'GitHub', value: profile.github, href: socialLinks.github, Icon: GitHubIcon, external: true },
  { label: 'LinkedIn', value: profile.linkedin, href: socialLinks.linkedin, Icon: LinkedInIcon, external: true },
];

const emptyForm = { name: '', email: '', message: '' };

export default function Contact() {
  const [form, setForm] = useState(emptyForm);
  const [errors, setErrors] = useState({});
  const [snackbarOpen, setSnackbarOpen] = useState(false);

  const handleChange = (field) => (event) => {
    setForm((prev) => ({ ...prev, [field]: event.target.value }));
    if (errors[field]) setErrors((prev) => ({ ...prev, [field]: undefined }));
  };

  const validate = () => {
    const next = {};
    if (!form.name.trim()) next.name = 'Please enter your name.';
    if (!/^\S+@\S+\.\S+$/.test(form.email)) next.email = 'Please enter a valid email address.';
    if (!form.message.trim()) next.message = 'Please write a message.';
    return next;
  };

  // Frontend-only: nothing is sent anywhere. Connect a backend or a form service to deliver messages.
  const handleSubmit = (event) => {
    event.preventDefault();
    const next = validate();
    setErrors(next);
    if (Object.keys(next).length > 0) return;
    setForm(emptyForm);
    setSnackbarOpen(true);
  };

  return (
    <Section id="contact" index={5} label="CONTACT" title="Let's build something together.">
      <Box
        sx={{
          display: 'grid',
          gridTemplateColumns: { xs: '1fr', md: '0.9fr 1.1fr' },
          gap: { xs: 5, md: 10 },
        }}
      >
        <Reveal>
          <Typography variant="body1" sx={{ color: tokens.textMuted, mb: 4, maxWidth: 420 }}>
            Open to internships, collaborations and interesting problems. Reach out through any of the links below
            or use the form.
          </Typography>
          <Stack component="ul" spacing={1} sx={{ listStyle: 'none', m: 0, p: 0 }}>
            {contactLinks.map(({ label, value, href, Icon, external }) => (
              <li key={label}>
                <Link
                  href={href}
                  {...(external ? { target: '_blank', rel: 'noopener noreferrer' } : {})}
                  underline="none"
                  aria-label={`${label}: ${value}${external ? ' (opens in a new tab)' : ''}`}
                  sx={{
                    display: 'flex',
                    alignItems: 'center',
                    gap: 2,
                    p: 1.75,
                    color: tokens.text,
                    border: `1px solid ${tokens.border}`,
                    borderRadius: 3,
                    transition: 'border-color 0.4s ease, background-color 0.4s ease, transform 0.4s ease',
                    '&:hover': {
                      borderColor: tokens.borderStrong,
                      backgroundColor: 'rgba(255,255,255,0.03)',
                      transform: 'translateX(4px)',
                    },
                    '&:hover .contact-icon': { color: tokens.accent },
                  }}
                >
                  <Icon className="contact-icon" aria-hidden="true" sx={{ color: tokens.textMuted, transition: 'color 0.4s ease' }} />
                  <Box sx={{ minWidth: 0 }}>
                    <Typography variant="caption" sx={{ color: tokens.textMuted, display: 'block' }}>
                      {label}
                    </Typography>
                    <Typography variant="body2" sx={{ color: tokens.text, overflowWrap: 'anywhere' }}>
                      {value}
                    </Typography>
                  </Box>
                </Link>
              </li>
            ))}
          </Stack>
        </Reveal>

        <Reveal delay={120}>
          <Box component="form" onSubmit={handleSubmit} noValidate aria-label="Contact form">
            <Stack spacing={2.5}>
              <TextField
                label="Name"
                name="name"
                autoComplete="name"
                value={form.name}
                onChange={handleChange('name')}
                error={Boolean(errors.name)}
                helperText={errors.name}
                required
              />
              <TextField
                label="Email"
                name="email"
                type="email"
                autoComplete="email"
                value={form.email}
                onChange={handleChange('email')}
                error={Boolean(errors.email)}
                helperText={errors.email}
                required
              />
              <TextField
                label="Message"
                name="message"
                multiline
                minRows={5}
                value={form.message}
                onChange={handleChange('message')}
                error={Boolean(errors.message)}
                helperText={errors.message}
                required
              />
              <Box>
                <Button type="submit" variant="contained" size="large" endIcon={<SendIcon />}>
                  Send Message
                </Button>
              </Box>
              <Typography variant="caption" sx={{ color: tokens.textMuted }}>
                Demo form: submissions are not sent anywhere yet.
              </Typography>
            </Stack>
          </Box>
        </Reveal>
      </Box>

      <Snackbar
        open={snackbarOpen}
        autoHideDuration={5000}
        onClose={(_, reason) => reason !== 'clickaway' && setSnackbarOpen(false)}
        anchorOrigin={{ vertical: 'bottom', horizontal: 'center' }}
      >
        <Alert onClose={() => setSnackbarOpen(false)} severity="info" variant="filled" sx={{ width: '100%' }}>
          Form validated. This demo does not send email yet; connect a backend to deliver messages.
        </Alert>
      </Snackbar>
    </Section>
  );
}
