import Box from '@mui/material/Box';
import Chip from '@mui/material/Chip';
import Stack from '@mui/material/Stack';
import Typography from '@mui/material/Typography';
import Section from './Section';
import Reveal from './Reveal';
import { timeline } from '../data/portfolio';
import { fontMono, tokens } from '../theme/theme';

export default function Education() {
  return (
    <Section id="education" index={4} label="EDUCATION" title="Education & experience">
      <Box component="ol" sx={{ listStyle: 'none', m: 0, p: 0, position: 'relative' }}>
        {timeline.map((item, i) => (
          <Reveal
            key={`${item.period}-${item.title}`}
            component="li"
            delay={i * 100}
            sx={{
              position: 'relative',
              display: 'grid',
              gridTemplateColumns: { xs: '1fr', md: '200px 1fr' },
              columnGap: { md: 6 },
              rowGap: 1,
              pl: { xs: 3.5, md: 0 },
              pb: i === timeline.length - 1 ? 0 : 6,
              // Vertical rail: left edge on mobile, between columns on desktop.
              '&::before': {
                content: '""',
                position: 'absolute',
                top: 6,
                bottom: 0,
                left: { xs: 3, md: 200 + 24 - 1 },
                width: '1px',
                bgcolor: tokens.border,
                display: i === timeline.length - 1 ? 'none' : 'block',
              },
              // Node on the rail.
              '&::after': {
                content: '""',
                position: 'absolute',
                top: 6,
                left: { xs: 0, md: 200 + 24 - 6 },
                width: 11,
                height: 11,
                borderRadius: '50%',
                bgcolor: tokens.bg,
                border: `2px solid ${tokens.accent}`,
              },
            }}
          >
            <Typography
              component="p"
              sx={{ fontFamily: fontMono, fontSize: '0.85rem', color: tokens.accent, pt: 0.25 }}
            >
              {item.period}
            </Typography>

            <Box sx={{ pl: { md: 3 } }}>
              <Typography variant="h3" component="h3" sx={{ mb: 0.75 }}>
                {item.title}
              </Typography>
              <Typography variant="body1" sx={{ color: tokens.text }}>
                {item.institution}
              </Typography>
              <Typography variant="body2" sx={{ color: tokens.textMuted, mb: 2.5 }}>
                {item.meta}
              </Typography>

              <Typography
                variant="overline"
                component="h4"
                sx={{ color: tokens.textMuted, display: 'block', mb: 1 }}
              >
                Relevant coursework
              </Typography>
              <Stack
                component="ul"
                direction="row"
                useFlexGap
                flexWrap="wrap"
                spacing={1}
                sx={{ listStyle: 'none', m: 0, p: 0 }}
              >
                {item.coursework.map((course) => (
                  <li key={course}>
                    <Chip label={course} size="small" />
                  </li>
                ))}
              </Stack>
              {item.note && (
                <Typography variant="caption" sx={{ display: 'block', mt: 2, color: tokens.textMuted }}>
                  {item.note}
                </Typography>
              )}
            </Box>
          </Reveal>
        ))}
      </Box>
    </Section>
  );
}
