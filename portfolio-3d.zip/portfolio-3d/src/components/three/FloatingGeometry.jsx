import { memo, useRef } from 'react';
import { useFrame } from '@react-three/fiber';
import { Float } from '@react-three/drei';
import { MathUtils } from 'three';
import { tokens } from '../../theme/theme';

// Abstract hero object: a faceted icosahedron core, a wireframe shell, a torus ring and an orbiting sphere.
// All geometry is low-poly. Geometries and materials are created declaratively, so R3F disposes them on unmount.
function FloatingGeometry({ animate = true, detail = 1 }) {
  const group = useRef(null);
  const shell = useRef(null);
  const ring = useRef(null);
  const orbit = useRef(null);

  useFrame((state, delta) => {
    if (!animate || !group.current) return;

    // Ease the whole object toward the pointer for a subtle parallax feel.
    const { x, y } = state.pointer;
    group.current.rotation.y = MathUtils.damp(group.current.rotation.y, x * 0.45, 3, delta);
    group.current.rotation.x = MathUtils.damp(group.current.rotation.x, -y * 0.3, 3, delta);

    if (shell.current) {
      shell.current.rotation.y += delta * 0.12;
      shell.current.rotation.x += delta * 0.06;
    }
    if (ring.current) ring.current.rotation.z += delta * 0.15;
    if (orbit.current) orbit.current.rotation.y += delta * 0.4;
  });

  return (
    <Float speed={animate ? 1.2 : 0} rotationIntensity={0.15} floatIntensity={animate ? 0.7 : 0}>
      <group ref={group}>
        {/* Core */}
        <mesh>
          <icosahedronGeometry args={[1, detail]} />
          <meshStandardMaterial
            color="#1a1f2b"
            metalness={0.6}
            roughness={0.35}
            flatShading
          />
        </mesh>

        {/* Wireframe shell */}
        <mesh ref={shell} scale={1.28}>
          <icosahedronGeometry args={[1, 1]} />
          <meshBasicMaterial color={tokens.accent} wireframe transparent opacity={0.35} />
        </mesh>

        {/* Ring */}
        <mesh ref={ring} rotation={[Math.PI / 2.4, 0, 0]}>
          <torusGeometry args={[1.85, 0.012, 8, 64]} />
          <meshBasicMaterial color={tokens.accentSoft} transparent opacity={0.8} />
        </mesh>

        {/* Orbiting sphere */}
        <group ref={orbit} rotation={[0.4, 0, 0.3]}>
          <mesh position={[2.3, 0, 0]}>
            <sphereGeometry args={[0.12, 16, 16]} />
            <meshStandardMaterial
              color={tokens.accent}
              emissive={tokens.accent}
              emissiveIntensity={0.9}
              roughness={0.3}
            />
          </mesh>
        </group>
      </group>
    </Float>
  );
}

export default memo(FloatingGeometry);
