import { memo, useMemo, useRef } from 'react';
import { useFrame } from '@react-three/fiber';
import { tokens } from '../../theme/theme';

// Sparse point cloud distributed in a hollow shell around the main object.
function ParticleField({ count = 160, radius = 4, size = 0.035, animate = true }) {
  const pointsRef = useRef(null);

  const positions = useMemo(() => {
    const array = new Float32Array(count * 3);
    for (let i = 0; i < count; i += 1) {
      // Uniform direction on a sphere, radius biased outward so the centre stays clear.
      const u = Math.random() * 2 - 1;
      const theta = Math.random() * Math.PI * 2;
      const r = radius * (0.6 + Math.random() * 0.4);
      const s = Math.sqrt(1 - u * u);
      array[i * 3] = r * s * Math.cos(theta);
      array[i * 3 + 1] = r * u;
      array[i * 3 + 2] = r * s * Math.sin(theta);
    }
    return array;
  }, [count, radius]);

  useFrame((_, delta) => {
    if (!animate || !pointsRef.current) return;
    pointsRef.current.rotation.y += delta * 0.03;
    pointsRef.current.rotation.x += delta * 0.01;
  });

  return (
    <points ref={pointsRef}>
      <bufferGeometry>
        <bufferAttribute attach="attributes-position" args={[positions, 3]} />
      </bufferGeometry>
      <pointsMaterial
        color={tokens.accentSoft}
        size={size}
        sizeAttenuation
        transparent
        opacity={0.7}
        depthWrite={false}
      />
    </points>
  );
}

export default memo(ParticleField);
