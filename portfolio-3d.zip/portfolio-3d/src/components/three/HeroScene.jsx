import { Suspense, useEffect, useRef, useState } from 'react';
import { Canvas } from '@react-three/fiber';
import Box from '@mui/material/Box';
import FloatingGeometry from './FloatingGeometry';
import ParticleField from './ParticleField';
import { tokens } from '../../theme/theme';
import { useIsMobile, usePrefersReducedMotion } from '../../hooks/useMediaFlags';

// Renders the canvas only while it is on screen and lowers the cost on phones.
export default function HeroScene() {
  const isMobile = useIsMobile();
  const reducedMotion = usePrefersReducedMotion();
  const wrapperRef = useRef(null);
  const [inView, setInView] = useState(true);

  // Pause the render loop completely when the hero scrolls out of view.
  useEffect(() => {
    const node = wrapperRef.current;
    if (!node || typeof IntersectionObserver === 'undefined') return undefined;
    const observer = new IntersectionObserver(([entry]) => setInView(entry.isIntersecting), {
      threshold: 0,
    });
    observer.observe(node);
    return () => observer.disconnect();
  }, []);

  // 'never' = paused, 'demand' = single static frame (reduced motion), 'always' = animated.
  let frameloop = 'always';
  if (!inView) frameloop = 'never';
  else if (reducedMotion) frameloop = 'demand';

  return (
    <Box
      ref={wrapperRef}
      aria-hidden="true"
      sx={{ position: 'absolute', inset: 0, touchAction: 'pan-y' }}
    >
      <Canvas
        frameloop={frameloop}
        dpr={isMobile ? [1, 1.25] : [1, 1.75]}
        camera={{ position: [0, 0, 6], fov: 40 }}
        gl={{ antialias: !isMobile, alpha: true, powerPreference: 'high-performance' }}
        style={{ background: 'transparent' }}
      >
        <ambientLight intensity={0.5} />
        <directionalLight position={[3, 4, 5]} intensity={1.6} />
        <pointLight position={[-4, -2, 2]} intensity={14} color={tokens.accent} />
        <Suspense fallback={null}>
          <FloatingGeometry animate={!reducedMotion} detail={isMobile ? 0 : 1} />
          <ParticleField count={isMobile ? 70 : 160} animate={!reducedMotion} />
        </Suspense>
      </Canvas>
    </Box>
  );
}
