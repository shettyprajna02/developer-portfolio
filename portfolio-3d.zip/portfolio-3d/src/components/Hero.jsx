import { lazy, Suspense } from 'react';
import Box from '@mui/material/Box';
import Container from '@mui/material/Container';
import Typography from '@mui/material/Typography';
import Button from '@mui/material/Button';
import Stack from '@mui/material/Stack';
import { alpha } from '@mui/material/styles';
import ErrorBoundary from './ErrorBoundary';
import { profile } from '../data/portfolio';
import { fontMono, tokens } from '../theme/theme';
import { scrollToSection } from '../utils/scroll';

// The 3D scene (three.js + R3F + drei) is split into its own chunk and loaded after first paint.
const HeroScene = lazy(() => import('./three/HeroScene'));

// Staggered fade/slide entrance for the hero copy.
const enter = (delayMs) => ({
  opacity: 0,
  animation: `fade-up 1s cubic-bezier(0.22, 1, 0.36, 1) ${delayMs}ms forwards`,
});

export default function Hero() {
  const goTo = (event, id) => {
    event.preventDefault();
    scrollToSection(id);
  };

  return (
    <Box
      component="section"
      id="home"
      aria-labelledby="hero-heading"
      sx={{
        position: 'relative',
        minHeight: { xs: 'auto', md: 'calc(100svh - 68px)' },
        display: 'flex',
        alignItems: 'center',
        pt: { xs: 4, md: 0 },
        pb: { xs: 8, md: 0 },
        overflow: 'hidden',
      }}
    >
      <Container maxWidth="lg">
        <Box
          sx={{
            display: 'grid',
            gridTemplateColumns: { xs: '1fr', md: '1.05fr 0.95fr' },
            alignItems: 'center',
            gap: { xs: 2, md: 4 },
          }}
        >
          {/* Copy */}
          <Box sx={{ position: 'relative', zIndex: 1, order: { xs: 2, md: 1 } }}>
            <Typography
              variant="overline"
              component="p"
              sx={{ color: tokens.accent, mb: 2, display: 'flex', alignItems: 'center', gap: 1.5, ...enter(100) }}
            >
              <Box
                component="span"
                aria-hidden="true"
                sx={{ width: 32, height: '1px', bgcolor: 'currentColor', opacity: 0.6 }}
              />
              {profile.eyebrow}
            </Typography>

            <Typography id="hero-heading" variant="h1" component="h1" sx={{ mb: 2, wordBreak: 'break-word', ...enter(220) }}>
              {profile.name}
            </Typography>

            <Typography variant="subtitle1" component="p" sx={{ color: tokens.text, mb: 2.5, ...enter(340) }}>
              {profile.role}
            </Typography>

            <Typography
              variant="body1"
              sx={{ color: tokens.textMuted, maxWidth: 520, mb: 4.5, ...enter(460) }}
            >
              {profile.tagline}
            </Typography>

            <Stack direction={{ xs: 'column', sm: 'row' }} spacing={1.5} sx={enter(580)}>
              <Button
                variant="contained"
                color="primary"
                size="large"
                href="#projects"
                onClick={(e) => goTo(e, 'projects')}
              >
                View Projects
              </Button>
              <Button variant="outlined" size="large" href="#contact" onClick={(e) => goTo(e, 'contact')}>
                Contact Me
              </Button>
            </Stack>

            <Box
              sx={{
                mt: 5,
                display: { xs: 'none', md: 'flex' },
                alignItems: 'center',
                gap: 1.5,
                color: tokens.textMuted,
                fontFamily: fontMono,
                fontSize: '0.75rem',
                letterSpacing: '0.12em',
                ...enter(760),
              }}
            >
              <Box
                aria-hidden="true"
                sx={{
                  width: 18,
                  height: 28,
                  border: `1px solid ${tokens.borderStrong}`,
                  borderRadius: 9,
                  display: 'flex',
                  justifyContent: 'center',
                  pt: '5px',
                }}
              >
                <Box
                  sx={{
                    width: 2,
                    height: 6,
                    borderRadius: 1,
                    bgcolor: tokens.accent,
                    animation: 'scroll-hint 2s ease-in-out infinite',
                  }}
                />
              </Box>
              SCROLL
            </Box>
          </Box>

          {/* 3D scene */}
          <Box
            sx={{
              position: 'relative',
              order: { xs: 1, md: 2 },
              height: { xs: 280, sm: 360, md: 520 },
              opacity: 0,
              animation: 'fade-in 1.6s ease 300ms forwards',
            }}
          >
            {/* Soft glow behind the object */}
            <Box
              aria-hidden="true"
              sx={{
                position: 'absolute',
                top: '50%',
                left: '50%',
                width: '70%',
                aspectRatio: '1',
                transform: 'translate(-50%, -50%)',
                borderRadius: '50%',
                background: `radial-gradient(circle, ${alpha(tokens.accent, 0.22)} 0%, transparent 68%)`,
                filter: 'blur(24px)',
              }}
            />
            <ErrorBoundary>
              <Suspense fallback={null}>
                <HeroScene />
              </Suspense>
            </ErrorBoundary>
          </Box>
        </Box>
      </Container>
    </Box>
  );
}
