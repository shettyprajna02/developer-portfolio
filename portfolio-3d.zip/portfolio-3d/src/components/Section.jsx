import Box from '@mui/material/Box';
import Container from '@mui/material/Container';
import Typography from '@mui/material/Typography';
import Reveal from './Reveal';
import { tokens } from '../theme/theme';

// Shared wrapper: anchor id, numbered section label, heading and consistent spacing.
export default function Section({ id, index, label, title, children, sx }) {
  const headingId = `${id}-heading`;

  return (
    <Box
      component="section"
      id={id}
      aria-labelledby={headingId}
      sx={{ py: { xs: 9, md: 14 }, ...sx }}
    >
      <Container maxWidth="lg">
        <Reveal sx={{ mb: { xs: 5, md: 7 } }}>
          <Typography
            variant="overline"
            component="p"
            sx={{ color: tokens.accent, display: 'flex', alignItems: 'center', gap: 1.5, mb: 1.5 }}
          >
            <span aria-hidden="true">{String(index).padStart(2, '0')}</span>
            <Box
              component="span"
              aria-hidden="true"
              sx={{ width: 32, height: '1px', bgcolor: 'currentColor', opacity: 0.6 }}
            />
            {label}
          </Typography>
          <Typography id={headingId} variant="h2" component="h2">
            {title}
          </Typography>
        </Reveal>
        {children}
      </Container>
    </Box>
  );
}
