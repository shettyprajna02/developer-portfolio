import Box from '@mui/material/Box';
import Container from '@mui/material/Container';
import Typography from '@mui/material/Typography';
import { footer, profile } from '../data/portfolio';
import { tokens } from '../theme/theme';

export default function Footer() {
  return (
    <Box component="footer" sx={{ borderTop: `1px solid ${tokens.border}`, py: 4 }}>
      <Container
        maxWidth="lg"
        sx={{
          display: 'flex',
          flexDirection: { xs: 'column', sm: 'row' },
          justifyContent: 'space-between',
          alignItems: { xs: 'flex-start', sm: 'center' },
          gap: 1,
        }}
      >
        <Typography variant="body2" sx={{ color: tokens.textMuted }}>
          &copy; {new Date().getFullYear()} {profile.name}
        </Typography>
        <Typography variant="body2" sx={{ color: tokens.textMuted }}>
          {footer.text}
        </Typography>
      </Container>
    </Box>
  );
}
