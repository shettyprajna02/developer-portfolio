import Box from '@mui/material/Box';
import Card from '@mui/material/Card';
import CardContent from '@mui/material/CardContent';
import Chip from '@mui/material/Chip';
import Stack from '@mui/material/Stack';
import Typography from '@mui/material/Typography';
import { alpha } from '@mui/material/styles';
import CodeIcon from '@mui/icons-material/Code';
import LanguageIcon from '@mui/icons-material/Language';
import StorageIcon from '@mui/icons-material/Storage';
import BuildOutlinedIcon from '@mui/icons-material/BuildOutlined';
import Section from './Section';
import Reveal from './Reveal';
import { skillCategories } from '../data/portfolio';
import { tokens } from '../theme/theme';

// One icon per category keeps the section quiet. Keys match titles in data/portfolio.js.
const categoryIcons = {
  Programming: CodeIcon,
  'Web Development': LanguageIcon,
  Database: StorageIcon,
  Tools: BuildOutlinedIcon,
};

export default function Skills() {
  return (
    <Section id="skills" index={2} label="SKILLS" title="Tools I work with">
      <Box
        sx={{
          display: 'grid',
          gridTemplateColumns: { xs: '1fr', sm: 'repeat(2, 1fr)' },
          gap: { xs: 2, md: 3 },
        }}
      >
        {skillCategories.map((category, i) => {
          const Icon = categoryIcons[category.title] ?? CodeIcon;
          return (
            <Reveal key={category.title} delay={i * 90}>
              <Card
                component="article"
                sx={{
                  height: '100%',
                  '&:hover': { transform: 'translateY(-4px)', borderColor: alpha(tokens.accent, 0.4) },
                  '&:hover .skill-icon': { color: tokens.accent },
                }}
              >
                <CardContent sx={{ p: { xs: 2.5, md: 3.5 } }}>
                  <Stack direction="row" alignItems="center" spacing={1.5} sx={{ mb: 2.5 }}>
                    <Icon
                      className="skill-icon"
                      aria-hidden="true"
                      fontSize="small"
                      sx={{ color: tokens.textMuted, transition: 'color 0.4s ease' }}
                    />
                    <Typography variant="h3" component="h3">
                      {category.title}
                    </Typography>
                  </Stack>
                  <Stack
                    component="ul"
                    direction="row"
                    useFlexGap
                    flexWrap="wrap"
                    spacing={1}
                    sx={{ listStyle: 'none', m: 0, p: 0 }}
                  >
                    {category.skills.map((skill) => (
                      <li key={skill}>
                        <Chip
                          label={skill}
                          sx={{
                            '&:hover': {
                              borderColor: alpha(tokens.accent, 0.5),
                              backgroundColor: alpha(tokens.accent, 0.08),
                              transform: 'translateY(-2px)',
                            },
                          }}
                        />
                      </li>
                    ))}
                  </Stack>
                </CardContent>
              </Card>
            </Reveal>
          );
        })}
      </Box>
    </Section>
  );
}
