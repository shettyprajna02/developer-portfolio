import { useEffect, useState } from 'react';
import Box from '@mui/material/Box';
import Typography from '@mui/material/Typography';
import Chip from '@mui/material/Chip';
import Stack from '@mui/material/Stack';
import Section from './Section';
import Reveal from './Reveal';
import useReveal from '../hooks/useReveal';
import { usePrefersReducedMotion } from '../hooks/useMediaFlags';
import { about } from '../data/portfolio';
import { fontMono, tokens } from '../theme/theme';

// Counts up to `value` once visible (instantly when reduced motion is on).
function CountUp({ value, suffix = '' }) {
  const [ref, visible] = useReveal({ threshold: 0.6 });
  const reduced = usePrefersReducedMotion();
  const [n, setN] = useState(reduced ? value : 0);

  useEffect(() => {
    if (!visible) return undefined;
    if (reduced) {
      setN(value);
      return undefined;
    }
    let frame;
    const start = performance.now();
    const duration = 1200;
    const tick = (now) => {
      const t = Math.min((now - start) / duration, 1);
      setN(Math.round(value * (1 - (1 - t) ** 3)));
      if (t < 1) frame = requestAnimationFrame(tick);
    };
    frame = requestAnimationFrame(tick);
    return () => cancelAnimationFrame(frame);
  }, [visible, value, reduced]);

  return (
    <span ref={ref}>
      {n}
      {suffix}
    </span>
  );
}

// Lightweight SVG graphic (no second WebGL context): concentric slowly rotating rings.
function OrbitGraphic() {
  return (
    <Box
      aria-hidden="true"
      sx={{
        position: 'relative',
        width: '100%',
        maxWidth: 260,
        aspectRatio: '1',
        mx: { xs: 'auto', md: 0 },
        mb: 4,
      }}
    >
      <Box
        component="svg"
        viewBox="0 0 200 200"
        sx={{ width: '100%', height: '100%', overflow: 'visible' }}
      >
        <g fill="none" stroke={tokens.accent} strokeWidth="0.6">
          <circle cx="100" cy="100" r="92" opacity="0.18" />
          <circle cx="100" cy="100" r="66" opacity="0.28" />
          <circle cx="100" cy="100" r="40" opacity="0.4" />
        </g>
        <g style={{ transformOrigin: '100px 100px', animation: 'spin-slow 40s linear infinite' }}>
          <circle cx="100" cy="8" r="3" fill={tokens.accent} />
          <circle cx="100" cy="100" r="92" fill="none" stroke={tokens.accent} strokeWidth="0.6" strokeDasharray="2 8" opacity="0.4" />
        </g>
        <g style={{ transformOrigin: '100px 100px', animation: 'spin-slow 26s linear infinite reverse' }}>
          <circle cx="100" cy="34" r="2.5" fill={tokens.accentSoft} />
        </g>
        <polygon
          points="100,78 119,89 119,111 100,122 81,111 81,89"
          fill="none"
          stroke={tokens.accentSoft}
          strokeWidth="1"
        />
      </Box>
    </Box>
  );
}

export default function About() {
  return (
    <Section id="about" index={1} label="ABOUT" title="A little about me">
      <Box
        sx={{
          display: 'grid',
          gridTemplateColumns: { xs: '1fr', md: '0.8fr 1.2fr' },
          gap: { xs: 5, md: 10 },
          alignItems: 'start',
        }}
      >
        <Reveal>
          <OrbitGraphic />
          <Box
            sx={{
              display: 'grid',
              gridTemplateColumns: 'repeat(3, 1fr)',
              border: `1px solid ${tokens.border}`,
              borderRadius: 3,
              overflow: 'hidden',
            }}
          >
            {about.stats.map((stat, i) => (
              <Box
                key={stat.label}
                sx={{
                  p: { xs: 1.5, sm: 2.5 },
                  textAlign: 'center',
                  borderLeft: i === 0 ? 'none' : `1px solid ${tokens.border}`,
                }}
              >
                <Typography
                  component="p"
                  sx={{ fontFamily: fontMono, fontSize: { xs: '1.4rem', sm: '1.8rem' }, color: tokens.text }}
                >
                  <CountUp value={stat.value} suffix={stat.suffix} />
                </Typography>
                <Typography variant="body2" sx={{ color: tokens.textMuted, fontSize: { xs: '0.72rem', sm: '0.85rem' } }}>
                  {stat.label}
                </Typography>
              </Box>
            ))}
          </Box>
          <Typography variant="caption" sx={{ display: 'block', mt: 1, color: tokens.textMuted }}>
            Placeholder numbers. Update them in src/data/portfolio.js.
          </Typography>
        </Reveal>

        <Reveal delay={120}>
          <Typography variant="body1" sx={{ color: tokens.text, mb: 4, fontSize: { xs: '1rem', md: '1.1rem' } }}>
            {about.intro}
          </Typography>

          <Stack spacing={3.5}>
            <Box>
              <Typography variant="overline" component="h3" sx={{ color: tokens.textMuted, display: 'block', mb: 0.75 }}>
                Education
              </Typography>
              <Typography variant="body1">{about.education}</Typography>
            </Box>

            <Box>
              <Typography variant="overline" component="h3" sx={{ color: tokens.textMuted, display: 'block', mb: 1 }}>
                Interests
              </Typography>
              <Stack direction="row" useFlexGap flexWrap="wrap" spacing={1}>
                {about.interests.map((interest) => (
                  <Chip key={interest} label={interest} size="small" />
                ))}
              </Stack>
            </Box>

            <Box>
              <Typography variant="overline" component="h3" sx={{ color: tokens.textMuted, display: 'block', mb: 0.75 }}>
                Development focus
              </Typography>
              <Typography variant="body1">{about.focus}</Typography>
            </Box>
          </Stack>
        </Reveal>
      </Box>
    </Section>
  );
}
