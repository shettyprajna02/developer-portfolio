import { useEffect, useState } from 'react';
import AppBar from '@mui/material/AppBar';
import Toolbar from '@mui/material/Toolbar';
import Container from '@mui/material/Container';
import Box from '@mui/material/Box';
import Button from '@mui/material/Button';
import IconButton from '@mui/material/IconButton';
import Drawer from '@mui/material/Drawer';
import List from '@mui/material/List';
import ListItemButton from '@mui/material/ListItemButton';
import ListItemText from '@mui/material/ListItemText';
import Typography from '@mui/material/Typography';
import { alpha } from '@mui/material/styles';
import MenuIcon from '@mui/icons-material/Menu';
import CloseIcon from '@mui/icons-material/Close';
import { navItems, profile } from '../data/portfolio';
import { fontMono, tokens } from '../theme/theme';
import { scrollToSection } from '../utils/scroll';

function useActiveSection(ids) {
  const [active, setActive] = useState(ids[0]);

  useEffect(() => {
    if (typeof IntersectionObserver === 'undefined') return undefined;
    const observer = new IntersectionObserver(
      (entries) => {
        entries.forEach((entry) => {
          if (entry.isIntersecting) setActive(entry.target.id);
        });
      },
      // Thin band through the middle of the viewport decides the active section.
      { rootMargin: '-45% 0px -50% 0px' },
    );
    ids.forEach((id) => {
      const el = document.getElementById(id);
      if (el) observer.observe(el);
    });
    return () => observer.disconnect();
  }, [ids]);

  return active;
}

const sectionIds = navItems.map((item) => item.id);

export default function Navbar() {
  const [scrolled, setScrolled] = useState(false);
  const [open, setOpen] = useState(false);
  const active = useActiveSection(sectionIds);

  useEffect(() => {
    const onScroll = () => setScrolled(window.scrollY > 24);
    onScroll();
    window.addEventListener('scroll', onScroll, { passive: true });
    return () => window.removeEventListener('scroll', onScroll);
  }, []);

  const handleNav = (event, id) => {
    event.preventDefault();
    setOpen(false);
    scrollToSection(id);
  };

  return (
    <>
      <AppBar
        position="sticky"
        color="transparent"
        elevation={0}
        component="header"
        sx={{
          top: 0,
          backgroundImage: 'none',
          backgroundColor: scrolled ? alpha(tokens.bg, 0.72) : 'transparent',
          backdropFilter: scrolled ? 'blur(14px)' : 'none',
          WebkitBackdropFilter: scrolled ? 'blur(14px)' : 'none',
          borderBottom: `1px solid ${scrolled ? tokens.border : 'transparent'}`,
          transition: 'background-color 0.5s ease, border-color 0.5s ease, backdrop-filter 0.5s ease',
        }}
      >
        <Container maxWidth="lg">
          <Toolbar
            component="nav"
            aria-label="Primary"
            disableGutters
            sx={{ minHeight: { xs: 60, md: 68 }, justifyContent: 'space-between' }}
          >
            <Box
              component="a"
              href="#home"
              onClick={(e) => handleNav(e, 'home')}
              aria-label={`${profile.name} - back to top`}
              sx={{
                display: 'inline-flex',
                alignItems: 'center',
                gap: 1,
                color: tokens.text,
                textDecoration: 'none',
                fontFamily: fontMono,
                fontSize: '0.9rem',
                borderRadius: 1,
                '&:focus-visible': { outline: `2px solid ${tokens.accent}`, outlineOffset: 4 },
              }}
            >
              <Box
                aria-hidden="true"
                sx={{
                  width: 8,
                  height: 8,
                  borderRadius: '50%',
                  bgcolor: tokens.accent,
                  animation: 'pulse-dot 2.6s ease-in-out infinite',
                }}
              />
              <span>{'<'}{profile.name}{' />'}</span>
            </Box>

            {/* Desktop links */}
            <Box sx={{ display: { xs: 'none', md: 'flex' }, gap: 0.5 }}>
              {navItems.map((item) => {
                const isActive = active === item.id;
                return (
                  <Button
                    key={item.id}
                    href={`#${item.id}`}
                    onClick={(e) => handleNav(e, item.id)}
                    aria-current={isActive ? 'location' : undefined}
                    size="small"
                    sx={{
                      color: isActive ? tokens.text : tokens.textMuted,
                      px: 1.75,
                      position: 'relative',
                      '&:hover': { color: tokens.text, backgroundColor: 'transparent', transform: 'none' },
                      '&::after': {
                        content: '""',
                        position: 'absolute',
                        left: 14,
                        right: 14,
                        bottom: 2,
                        height: '1px',
                        bgcolor: tokens.accent,
                        transform: isActive ? 'scaleX(1)' : 'scaleX(0)',
                        transformOrigin: 'left',
                        transition: 'transform 0.4s ease',
                      },
                    }}
                  >
                    {item.label}
                  </Button>
                );
              })}
            </Box>

            {/* Mobile hamburger */}
            <IconButton
              onClick={() => setOpen(true)}
              aria-label="Open navigation menu"
              aria-expanded={open}
              aria-controls="mobile-nav"
              sx={{
                display: { xs: 'inline-flex', md: 'none' },
                color: tokens.text,
                '&.Mui-focusVisible': { outline: `2px solid ${tokens.accent}` },
              }}
            >
              <MenuIcon />
            </IconButton>
          </Toolbar>
        </Container>
      </AppBar>

      <Drawer
        anchor="right"
        open={open}
        onClose={() => setOpen(false)}
        slotProps={{
          paper: {
            id: 'mobile-nav',
            sx: {
              width: 'min(80vw, 300px)',
              backgroundColor: alpha(tokens.surface, 0.96),
              backgroundImage: 'none',
              borderLeft: `1px solid ${tokens.border}`,
            },
          },
        }}
      >
        <Box sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', p: 2 }}>
          <Typography variant="overline" sx={{ color: tokens.textMuted }}>
            Menu
          </Typography>
          <IconButton onClick={() => setOpen(false)} aria-label="Close navigation menu" sx={{ color: tokens.text }}>
            <CloseIcon />
          </IconButton>
        </Box>
        <List component="nav" aria-label="Mobile">
          {navItems.map((item) => (
            <ListItemButton
              key={item.id}
              component="a"
              href={`#${item.id}`}
              onClick={(e) => handleNav(e, item.id)}
              selected={active === item.id}
              sx={{
                py: 1.5,
                px: 3,
                '&.Mui-selected': { backgroundColor: alpha(tokens.accent, 0.08), color: tokens.accent },
              }}
            >
              <ListItemText primary={item.label} slotProps={{ primary: { fontSize: '1.05rem' } }} />
            </ListItemButton>
          ))}
        </List>
      </Drawer>
    </>
  );
}
