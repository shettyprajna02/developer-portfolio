import Box from '@mui/material/Box';
import Card from '@mui/material/Card';
import CardContent from '@mui/material/CardContent';
import CardActions from '@mui/material/CardActions';
import Button from '@mui/material/Button';
import Chip from '@mui/material/Chip';
import Stack from '@mui/material/Stack';
import Typography from '@mui/material/Typography';
import GitHubIcon from '@mui/icons-material/GitHub';
import OpenInNewIcon from '@mui/icons-material/OpenInNew';
import Section from './Section';
import Reveal from './Reveal';
import useTilt from '../hooks/useTilt';
import { projects } from '../data/portfolio';
import { fontMono, tokens } from '../theme/theme';

function ProjectCard({ project, index }) {
  const { ref, handlers } = useTilt({ max: 4, scale: 1.01 });

  return (
    <Reveal delay={index * 100} sx={{ height: '100%' }}>
      <Card
        ref={ref}
        component="article"
        {...handlers}
        sx={{
          height: '100%',
          display: 'flex',
          flexDirection: 'column',
          willChange: 'transform',
          // Tilt is applied inline by the hook; this keeps the return-to-rest smooth.
          transition: 'transform 0.35s ease-out, border-color 0.4s ease, box-shadow 0.4s ease',
        }}
      >
        <CardContent sx={{ p: { xs: 2.5, md: 3.5 }, flexGrow: 1 }}>
          <Typography
            variant="caption"
            component="p"
            sx={{ fontFamily: fontMono, color: tokens.accent, letterSpacing: '0.12em', mb: 2 }}
          >
            {String(index + 1).padStart(2, '0')}
          </Typography>
          <Typography variant="h3" component="h3" sx={{ mb: 1.5 }}>
            {project.title}
          </Typography>
          <Typography variant="body2" sx={{ color: tokens.textMuted, mb: 3 }}>
            {project.description}
          </Typography>
          <Stack
            component="ul"
            direction="row"
            useFlexGap
            flexWrap="wrap"
            spacing={0.75}
            aria-label={`Technologies used in ${project.title}`}
            sx={{ listStyle: 'none', m: 0, p: 0 }}
          >
            {project.tech.map((tech) => (
              <li key={tech}>
                <Chip label={tech} size="small" />
              </li>
            ))}
          </Stack>
        </CardContent>
        <CardActions sx={{ px: { xs: 2.5, md: 3.5 }, pb: { xs: 2.5, md: 3.5 }, pt: 0, gap: 1 }}>
          <Button
            variant="outlined"
            size="small"
            href={project.github}
            target="_blank"
            rel="noopener noreferrer"
            startIcon={<GitHubIcon />}
            aria-label={`${project.title} on GitHub (opens in a new tab)`}
          >
            GitHub
          </Button>
          {project.demo && (
            <Button
              variant="contained"
              size="small"
              href={project.demo}
              target="_blank"
              rel="noopener noreferrer"
              endIcon={<OpenInNewIcon />}
              aria-label={`${project.title} live demo (opens in a new tab)`}
            >
              Live Demo
            </Button>
          )}
        </CardActions>
      </Card>
    </Reveal>
  );
}

export default function Projects() {
  return (
    <Section id="projects" index={3} label="PROJECTS" title="Selected work">
      <Box
        sx={{
          display: 'grid',
          gridTemplateColumns: { xs: '1fr', md: 'repeat(2, 1fr)', lg: 'repeat(3, 1fr)' },
          gap: { xs: 2, md: 3 },
        }}
      >
        {projects.map((project, i) => (
          <ProjectCard key={project.title} project={project} index={i} />
        ))}
      </Box>
      <Typography variant="caption" sx={{ display: 'block', mt: 3, color: tokens.textMuted }}>
        Project links are placeholders. Update them in src/data/portfolio.js.
      </Typography>
    </Section>
  );
}
