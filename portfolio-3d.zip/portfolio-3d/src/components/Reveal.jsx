import Box from '@mui/material/Box';
import useReveal from '../hooks/useReveal';

// Fades and slides its children in once they scroll into view. `delay` is in ms.
export default function Reveal({ children, delay = 0, sx, ...rest }) {
  const [ref, visible] = useReveal();

  return (
    <Box
      ref={ref}
      sx={{
        opacity: visible ? 1 : 0,
        transform: visible ? 'none' : 'translateY(24px)',
        transition: `opacity 0.9s ease ${delay}ms, transform 0.9s cubic-bezier(0.22, 1, 0.36, 1) ${delay}ms`,
        '@media (prefers-reduced-motion: reduce)': { opacity: 1, transform: 'none', transition: 'none' },
        ...sx,
      }}
      {...rest}
    >
      {children}
    </Box>
  );
}
