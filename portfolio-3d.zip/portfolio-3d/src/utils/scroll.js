// Smooth-scroll to a section by id, respecting reduced-motion preferences.
export function scrollToSection(id) {
  const el = document.getElementById(id);
  if (!el) return;
  const reduce = window.matchMedia?.('(prefers-reduced-motion: reduce)').matches;
  el.scrollIntoView({ behavior: reduce ? 'auto' : 'smooth', block: 'start' });
  // Keep the URL hash in sync without triggering a jump.
  window.history.replaceState(null, '', `#${id}`);
}
