// Single source of truth for all portfolio content.
// Every value marked "YOUR ..." or "PLACEHOLDER" is a placeholder: replace it before publishing.

export const profile = {
  name: 'YOUR NAME',
  role: 'Computer Science Student & Developer',
  eyebrow: 'HELLO, I’M',
  tagline:
    'I build thoughtful digital experiences by combining clean code, modern technologies, and creative problem solving.',
  email: 'YOUR EMAIL',
  github: 'YOUR GITHUB',
  linkedin: 'YOUR LINKEDIN',
  location: 'YOUR LOCATION',
};

// Where the social links point. Replace the URLs (or leave '#' until ready).
export const socialLinks = {
  email: 'mailto:YOUR_EMAIL@example.com',
  github: 'https://github.com/YOUR_GITHUB',
  linkedin: 'https://www.linkedin.com/in/YOUR_LINKEDIN',
};

export const navItems = [
  { label: 'Home', id: 'home' },
  { label: 'About', id: 'about' },
  { label: 'Skills', id: 'skills' },
  { label: 'Projects', id: 'projects' },
  { label: 'Education', id: 'education' },
  { label: 'Contact', id: 'contact' },
];

export const about = {
  intro:
    'PLACEHOLDER: Write two or three sentences about yourself here. Who you are, what drives you, and what you enjoy building.',
  education: 'Bachelor of Engineering — Computer Science & Engineering, YOUR COLLEGE',
  interests: ['Web Development', 'Parallel Computing', 'Graph Theory', 'Problem Solving'],
  focus:
    'PLACEHOLDER: Describe your development focus, for example full-stack web apps, systems programming, or algorithms.',
  // PLACEHOLDER numbers: update with your real figures. Do not leave invented values.
  stats: [
    { label: 'Projects', value: 3, suffix: '' },
    { label: 'Technologies', value: 12, suffix: '+' },
    { label: 'Years Learning', value: 3, suffix: '' },
  ],
};

export const skillCategories = [
  {
    title: 'Programming',
    skills: ['C', 'C++', 'Java', 'Python', 'JavaScript'],
  },
  {
    title: 'Web Development',
    skills: ['HTML', 'CSS', 'React', 'REST APIs'],
  },
  {
    title: 'Database',
    skills: ['MySQL', 'SQL'],
  },
  {
    title: 'Tools',
    skills: ['Git', 'GitHub', 'VS Code'],
  },
];

export const projects = [
  {
    title: 'Inventory Management System',
    description:
      'A web application for tracking stock, suppliers, and orders, backed by a REST API and a relational database.',
    tech: ['HTML', 'CSS', 'JavaScript', 'REST API', 'MySQL'],
    github: 'https://github.com/YOUR_GITHUB/inventory-management-system',
    demo: 'https://example.com/inventory-demo',
  },
  {
    title: 'Matrix Multiplication Performance Analyzer',
    description:
      'Benchmarks serial and parallel matrix multiplication to study speedup and scaling across thread counts.',
    tech: ['C', 'OpenMP', 'Parallel Computing'],
    github: 'https://github.com/YOUR_GITHUB/matrix-multiplication-analyzer',
    demo: null,
  },
  {
    title: 'Graph Theory Visualization',
    description:
      'Generates and visualizes graphs and classic algorithms to make structure and traversal easier to understand.',
    tech: ['Python', 'NetworkX', 'Matplotlib'],
    github: 'https://github.com/YOUR_GITHUB/graph-theory-visualization',
    demo: null,
  },
];

export const timeline = [
  {
    period: '2023 — Present',
    title: 'Bachelor of Engineering — Computer Science & Engineering',
    institution: 'YOUR COLLEGE',
    meta: 'YOUR UNIVERSITY · YOUR LOCATION',
    coursework: [
      'Data Structures & Algorithms',
      'Database Management Systems',
      'Operating Systems',
      'Computer Networks',
    ],
    note: 'PLACEHOLDER: replace the coursework with your own.',
  },
];

export const footer = {
  text: 'Designed & built with React, Three.js and Material UI.',
};
