import { useCallback, useEffect, useRef } from 'react';
import { usePrefersReducedMotion } from './useMediaFlags';

// Subtle 3D tilt for cards. Mutates the style directly (no React re-renders on mousemove).
// Spread the returned handlers onto the element and attach `ref`.
export default function useTilt({ max = 5, scale = 1.015 } = {}) {
  const ref = useRef(null);
  const frame = useRef(0);
  const reduced = usePrefersReducedMotion();

  const reset = useCallback(() => {
    cancelAnimationFrame(frame.current);
    const node = ref.current;
    if (node) node.style.transform = '';
  }, []);

  const onPointerMove = useCallback(
    (event) => {
      // Touch interactions should scroll, not tilt.
      if (reduced || event.pointerType === 'touch') return;
      const node = ref.current;
      if (!node) return;
      const { clientX, clientY } = event;
      cancelAnimationFrame(frame.current);
      frame.current = requestAnimationFrame(() => {
        const rect = node.getBoundingClientRect();
        const px = (clientX - rect.left) / rect.width - 0.5;
        const py = (clientY - rect.top) / rect.height - 0.5;
        node.style.transform = `perspective(900px) rotateX(${(-py * max).toFixed(2)}deg) rotateY(${(px * max).toFixed(2)}deg) scale(${scale})`;
      });
    },
    [max, scale, reduced],
  );

  useEffect(() => reset, [reset]);

  return { ref, handlers: { onPointerMove, onPointerLeave: reset } };
}
