import { useEffect, useState } from 'react';

function useMediaQueryFlag(query, fallback = false) {
  const [matches, setMatches] = useState(() =>
    typeof window !== 'undefined' && window.matchMedia ? window.matchMedia(query).matches : fallback,
  );

  useEffect(() => {
    if (!window.matchMedia) return undefined;
    const mql = window.matchMedia(query);
    const onChange = (e) => setMatches(e.matches);
    setMatches(mql.matches);
    mql.addEventListener('change', onChange);
    return () => mql.removeEventListener('change', onChange);
  }, [query]);

  return matches;
}

export const usePrefersReducedMotion = () => useMediaQueryFlag('(prefers-reduced-motion: reduce)');

// Coarse pointer or narrow screen: used to lower 3D complexity.
export const useIsMobile = () => useMediaQueryFlag('(max-width: 767px), (pointer: coarse)');
