# 3D Minimal Portfolio

React + Vite + Three.js (React Three Fiber + Drei) + Material UI.

## Run

```bash
npm install
npm run dev        # http://localhost:5173
npm run build      # production build in dist/
npm run preview    # serve the production build locally
```

Requires Node 18+ (Node 20+ recommended).

## Customize

All content lives in `src/data/portfolio.js`: name, role, email/GitHub/LinkedIn, about text and stats,
skills, projects, education timeline and footer. Every `YOUR ...` value and every line marked `PLACEHOLDER`
must be replaced. Social URLs are in `socialLinks`.

Colors and typography are in `src/theme/theme.js` (`tokens` holds the palette; change `accent` to re-theme).

## Structure

```
src/
  components/        Navbar, Hero, About, Skills, Projects, Education, Contact, Footer,
                     Section, Reveal, ErrorBoundary
  components/three/  HeroScene, FloatingGeometry, ParticleField
  hooks/             useReveal, useTilt, useMediaFlags
  data/portfolio.js  all editable content
  theme/theme.js     MUI theme + design tokens
  utils/scroll.js    smooth scrolling helper
```

## Notes

- The contact form is frontend-only and does not send email. To deliver messages, post the form to a backend
  or a form service (Formspree, Web3Forms, EmailJS) inside `handleSubmit` in `Contact.jsx`.
- The 3D scene pauses when off-screen, renders one static frame with `prefers-reduced-motion`, and uses fewer
  particles and lower pixel ratio on phones. If WebGL is unavailable the page still works without it.
- Fonts (Inter, Space Grotesk, JetBrains Mono) load from Google Fonts in `index.html`.

## Deploy

**Vercel / Netlify:** import the repo; build command `npm run build`, output directory `dist`.

**GitHub Pages:** set `base: '/<repo-name>/'` in `vite.config.js`, run `npm run build`, and publish `dist/`
(for example with the `actions/deploy-pages` workflow).
